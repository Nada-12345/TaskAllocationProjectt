import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Creating tasks
        Task task1 = new Task("T1", "Deliver Package", 5, 50, 4,
                Arrays.asList("Machine A", "Skill B"), "2024-12-20T18:00", Task.TaskStatus.PENDING);
        Task task2 = new Task("T2", "Fix Machine", 3, 30, 3,
                Arrays.asList("Machine A", "Skill C"), "2024-12-18T12:00", Task.TaskStatus.PENDING);
        Task task3 = new Task("T3", "Repair Engine", 4, 40, 2,
                Arrays.asList("Skill A", "Skill B"), "2024-12-22T12:00", Task.TaskStatus.PENDING);
        Task task4 = new Task("T4", "Test Machine", 2, 20, 5,
                Arrays.asList("Skill B", "Skill C"), "2024-12-25T09:00", Task.TaskStatus.PENDING);
        Task task5 = new Task("T5", "Clean Factory", 6, 60, 3,
                Arrays.asList("Skill A", "Skill C"), "2024-12-28T12:00", Task.TaskStatus.PENDING);
        Task task6 = new Task("T6", "Inspect Equipment", 5, 45, 4,
                Arrays.asList("Skill A", "Skill B"), "2024-12-30T10:00", Task.TaskStatus.PENDING);
        Task task7 = new Task("T7", "Install Software", 4, 40, 5,
                Arrays.asList("Skill C", "Skill B"), "2024-12-22T15:00", Task.TaskStatus.PENDING);
        Task task8 = new Task("T9", "Organize Workshop", 7, 70, 2,
                Arrays.asList("Skill C", "Skill A"), "2024-12-24T16:00", Task.TaskStatus.PENDING);

        // Creating more agents with varying skills, availability, and capacity
        Agent agent1 = new Agent("A1", "Agent 1", Arrays.asList("Skill B", "Skill C"), 10);
        Agent agent2 = new Agent("A2", "Agent 2", Arrays.asList("Skill A"), 8);
        Agent agent3 = new Agent("A3", "Agent 3", Arrays.asList("Skill A", "Skill B"), 7);
        Agent agent4 = new Agent("A4", "Agent 4", Arrays.asList("Skill C", "Skill A"), 6);
        Agent agent5 = new Agent("A5", "Agent 5", Arrays.asList("Skill B", "Skill C"), 5);
        Agent agent6 = new Agent("A6", "Agent 6", Arrays.asList("Skill A", "Skill C"), 9);
        Agent agent7 = new Agent("A7", "Agent 7", Arrays.asList("Skill B"), 7);

        // List of tasks and agents
        List<Task> tasks = new ArrayList<>(Arrays.asList(task1, task2, task3, task4, task5, task6, task7, task8));
        List<Agent> agents = new ArrayList<>(Arrays.asList(agent1, agent2, agent3, agent4, agent5, agent6, agent7S));

        // Visualize the tasks and agents
        TaskAllocationVisualizer.visualizeTasksAndAgents(tasks, agents);  // Visualization is triggered here

        // The user can click the button to run the algorithm (no need to manually call the algorithm here)
        TaskAllocatorDP.allocateTasks(tasks, agents);
    }
}
