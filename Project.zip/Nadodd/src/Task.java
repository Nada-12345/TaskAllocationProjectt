import java.util.List;

public class Task {
    private String taskId;
    private String taskName;
    private double duration;
    private double cost;
    private int priority;
    private List<String> resourcesRequired;
    private String deadline;
    private String assignedAgent;
    private TaskStatus status;

    public Task(String taskId, String taskName, double duration, double cost, int priority,
                List<String> resourcesRequired, String deadline, TaskStatus status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.duration = duration;
        this.cost = cost;
        this.priority = priority;
        this.resourcesRequired = resourcesRequired;
        this.deadline = deadline;
        this.status = status;
        this.assignedAgent = null;  // Initially, no agent is assigned
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public List<String> getResourcesRequired() {
        return resourcesRequired;
    }

    public void setResourcesRequired(List<String> resourcesRequired) {
        this.resourcesRequired = resourcesRequired;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getAssignedAgent() {
        return assignedAgent;
    }

    public void setAssignedAgent(String assignedAgent) {
        this.assignedAgent = assignedAgent;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId='" + taskId + '\'' +
                ", taskName='" + taskName + '\'' +
                ", duration=" + duration +
                ", cost=" + cost +
                ", priority=" + priority +
                ", resourcesRequired=" + resourcesRequired +
                ", deadline='" + deadline + '\'' +
                ", assignedAgent='" + assignedAgent + '\'' +
                ", status=" + status +
                '}';
    }

    public enum TaskStatus {
        PENDING("Pending"),
        IN_PROGRESS("In Progress"),
        COMPLETED("Completed"),
        ON_HOLD("On Hold");

        private String status;

        TaskStatus(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status){
            this.status = status;
        }

    }


}
