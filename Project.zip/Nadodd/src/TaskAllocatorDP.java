import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class TaskAllocatorDP {
    public static void allocateTasks(List<Task> tasks, List<Agent> agents) {
        int numTasks = tasks.size();
        int numAgents = agents.size();

        // dp[i][j] represents the maximum priority sum for allocating first i tasks to the first j agents
        int[][] dp = new int[numTasks + 1][numAgents + 1];
        int[][] taskAssignment = new int[numTasks + 1][numAgents + 1]; // Track assignments

        // Fill the DP table
        for (int i = 1; i <= numTasks; i++) {
            for (int j = 1; j <= numAgents; j++) {
                Task currentTask = tasks.get(i - 1);
                Agent currentAgent = agents.get(j - 1);

                // Carry forward the previous value if no assignment is made
                dp[i][j] = dp[i][j - 1];

                // Check if the agent can handle the task
                if (currentAgent.canCompleteTask(currentTask)) {
                    int newPrioritySum = dp[i - 1][j - 1] + currentTask.getPriority();
                    if (newPrioritySum > dp[i][j]) {
                        dp[i][j] = newPrioritySum;
                        taskAssignment[i][j] = j; // Assign task i to agent j
                    }
                }
            }
        }

        // Retrieve the assignments from the DP table
        List<String> assignments = new ArrayList<>();
        int i = numTasks, j = numAgents;
        while (i > 0 && j > 0) {
            if (taskAssignment[i][j] != 0) {
                assignments.add("Task " + tasks.get(i - 1).getTaskName() + " assigned to Agent " + agents.get(taskAssignment[i][j] - 1).getAgentName());
                i--;
            }
            j--;
        }

        // Print the assignments
        Collections.reverse(assignments);
        for (String assignment : assignments) {
            System.out.println(assignment);
        }

        // Print the total priority sum
        System.out.println("Maximum Priority Sum: " + dp[numTasks][numAgents]);
    }
}

