import java.util.*;

public class TaskAllocatorGreedy {
    // Method to perform the greedy task allocation
    public static void allocateTasks(List<Task> tasks, List<Agent> agents) {
        // Sort tasks by priority (highest priority first)
        tasks.sort((task1, task2) -> Integer.compare(task2.getPriority(), task1.getPriority()));

        // Try to allocate tasks to agents
        for (Task task : tasks) {
            Agent bestAgent = null;

            // Find the best agent who can complete the task
            for (Agent agent : agents) {
                if (agent.canCompleteTask(task)) {
                    if (bestAgent == null || agent.getAvailableTime() > bestAgent.getAvailableTime()) {
                        bestAgent = agent;
                    }
                }
            }

            // If a suitable agent is found, assign the task
            if (bestAgent != null && bestAgent.assignTask(task)) {
                // Task successfully assigned, no further action needed
            } else {
                System.out.println("No agent can complete Task '" + task.getTaskName() + "' due to lack of resources or time.");
            }
        }
    }
}