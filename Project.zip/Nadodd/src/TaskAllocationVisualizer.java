import javax.swing.*;
import java.awt.*;
import java.awt.geom.QuadCurve2D;
import java.util.List;

public class TaskAllocationVisualizer extends JPanel {

    private List<Task> tasks;
    private List<Agent> agents;
    private JButton runButton;

    public TaskAllocationVisualizer(List<Task> tasks, List<Agent> agents) {
        this.tasks = tasks;
        this.agents = agents;
        setLayout(null);  // Use absolute positioning for better control

        // Create a button to start the algorithm
        runButton = new JButton("Run Task Allocation");
        runButton.setBounds(50, 400, 200, 40);
        runButton.setBackground(new Color(0, 204, 102));  // Soft green
        runButton.setForeground(Color.WHITE);
        runButton.addActionListener(e -> runAlgorithm());
        add(runButton);
    }

    // Custom drawing panel for visualization
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Set the font for rendering task and agent text
        g2d.setFont(new Font("Arial", Font.PLAIN, 14));

        // Draw Tasks on the left side
        g2d.setColor(new Color(0, 102, 204));  // Soft blue for tasks
        int yPos = 50;
        for (Task task : tasks) {
            g2d.fillRoundRect(50, yPos, 200, 30, 10, 10);
            g2d.setColor(Color.WHITE);
            g2d.drawString("Task: " + task.getTaskName(), 55, yPos + 20);
            g2d.setColor(new Color(0, 102, 204));  // Soft blue for tasks
            yPos += 50;
        }

        // Draw Agents stacked under each other on the right side
        g2d.setColor(new Color(0, 153, 76));  // Softer green for agents
        int xPos = 300;
        int agentYOffset = 50; // Start drawing agents at a vertical offset
        for (Agent agent : agents) {
            g2d.fillRoundRect(xPos, agentYOffset, 200, 30, 10, 10);
            g2d.setColor(Color.WHITE);
            g2d.drawString(agent.getAgentName() + " - Time: " + agent.getAvailableTime(), xPos + 5, agentYOffset + 20);
            g2d.setColor(new Color(0, 153, 76));  // Softer green for agents
            agentYOffset += 50;
        }

        // Draw smooth curves (instead of sharp lines) indicating task assignments
        g2d.setColor(Color.RED);
        for (Task task : tasks) {
            if (task.getAssignedAgent() != null) {
                int agentIndex = getAgentIndexByName(task.getAssignedAgent());
                if (agentIndex != -1) {
                    // Drawing a smooth curve using QuadCurve2D
                    int taskCenterX = 150;
                    int taskCenterY = 50 + tasks.indexOf(task) * 50 + 20;
                    int agentCenterX = 350;
                    int agentCenterY = 50 + agentIndex * 50 + 20;  // Adjust agent position according to its index
                    QuadCurve2D.Float curve = new QuadCurve2D.Float(taskCenterX, taskCenterY,
                            (float) (taskCenterX + agentCenterX) / 2, taskCenterY - 100, agentCenterX, agentCenterY);
                    g2d.draw(curve);
                }
            }
        }
    }

    // Find the agent index based on the agent's name
    private int getAgentIndexByName(String agentName) {
        for (int i = 0; i < agents.size(); i++) {
            if (agents.get(i).getAgentName().equals(agentName)) {
                return i;
            }
        }
        return -1;  // Return -1 if no match is found
    }

    // Method to create and show the JFrame with visualization
    public static void visualizeTasksAndAgents(List<Task> tasks, List<Agent> agents) {
        JFrame frame = new JFrame("Task Allocation Visualization");
        TaskAllocationVisualizer visualizer = new TaskAllocationVisualizer(tasks, agents);
        frame.add(visualizer);
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Runs the algorithm and updates the visualization in real-time
    private void runAlgorithm() {
        TaskAllocatorGreedy.allocateTasks(tasks, agents);
        repaint();  // Repaints the panel to show the task assignments
    }
}
