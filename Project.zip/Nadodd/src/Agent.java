import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Agent {
    private String agentId;
    private String agentName;
    private List<String> skills;
    private double availableTime;  // Available working hours
    private List<Task> assignedTasks;

    public Agent(String agentId, String agentName, List<String> skills, double availableTime) {
        this.agentId = agentId;
        this.agentName = agentName;
        this.skills = skills;
        this.availableTime = availableTime;
        this.assignedTasks = new ArrayList<>();
    }

    // Getter and setter methods
    public String getAgentId() {
        return agentId;
    }

    public String getAgentName() {
        return agentName;
    }

    public List<String> getSkills() {
        return skills;
    }

    public double getAvailableTime() {
        return availableTime;
    }

    public List<Task> getAssignedTasks() {
        return assignedTasks;
    }

    public boolean assignTask(Task task) {
        if (canCompleteTask(task)) {
            assignedTasks.add(task);
            task.setAssignedAgent(agentName);
            task.setStatus(Task.TaskStatus.IN_PROGRESS);
            availableTime -= task.getDuration();
            System.out.println("Task '" + task.getTaskName() + "' assigned to  '" + agentName + "'.");
            return true;
        }
        System.out.println("Agent '" + agentName + "' cannot complete Task '" + task.getTaskName() + "' due to insufficient resources or time.");
        return false;
    }

    public boolean canCompleteTask(Task task) {
        // Check if the agent has required skills and enough available time to complete the task
        return (new HashSet<>(skills).containsAll(task.getResourcesRequired()) && availableTime >= task.getDuration());

    }

    public void completeTask(Task task) {
        if (assignedTasks.contains(task)) {
            task.setStatus(Task.TaskStatus.COMPLETED);
            availableTime += task.getDuration();  // Assuming time is freed up after completion
            assignedTasks.remove(task);
            System.out.println("Task '" + task.getTaskName() + "' completed by Agent '" + agentName + "'.");
        } else {
            System.out.println("Task '" + task.getTaskName() + "' is not assigned to Agent '" + agentName + "'.");
        }
    }

    @Override
    public String toString() {
        return "Agent{" +
                "agentId='" + agentId + '\'' +
                ", agentName='" + agentName + '\'' +
                ", skills=" + skills +
                ", availableTime=" + availableTime +
                ", assignedTasks=" + assignedTasks +
                '}';
    }
}
